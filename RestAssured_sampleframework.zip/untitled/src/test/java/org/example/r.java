package org.example;

public class r {
    public static void main(String[]args){
        String a= "hello";
        String b="World";
        String c=a.concat(b);
        System.out.println(c);
    }
}

