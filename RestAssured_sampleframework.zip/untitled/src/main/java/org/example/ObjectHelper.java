package org.example;

public class ObjectHelper {
    public static final String BASEURI= "https://api.apis.guru";
    public static String getSampleTestDataFile= "C://Users//BigRhaq//Downloads//selenium-cucumber-java-maven-example-master//untitled//src//test//java//testdata//sendSMS_TestData_dev01.json";
    public static String sendSampleApiEndpoint= System.getProperty("User.dir") +"/src/tst/resources/testdata/" + "/v2/providers.json";


}
